/*
* File:   main.c
* Author: Dr. T
*/

#define _CRT_SECURE_NO_WARNINGS

#include <stdio.h>
#include <stdlib.h>

float getFloat();

/*
* Graded Exercise 5
*/
int main(int argc, char** argv)
{
	// Problem 1: Define type for GPS coordinates

	// Problem 2: Declare and initialize variables

	// Problem 3: Print latitude and longitude differences

	return (EXIT_SUCCESS);
}

/*
* Gets a floating-point number from the user
*/
float getFloat()
{
	float number;
	scanf("%f", &number);
	return number;
}

